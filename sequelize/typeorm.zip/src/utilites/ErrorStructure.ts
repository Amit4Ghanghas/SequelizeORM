export interface ErrorStructure {
  code: number;
  errorObj?: string | object;
  errorsArray?: any[];
}
